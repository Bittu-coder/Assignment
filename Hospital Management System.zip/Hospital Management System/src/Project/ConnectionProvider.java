
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Project;
import java.sql.*;

/**
 *
 * @author Bittu Kumar
 */
public class ConnectionProvider {
    public static Connection getCon()
    {
    try
    {
    Class.forName("jdbc:mysql/project");
    Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","Root@1234");
    return con;
    }
    catch(Exception e)
    {
     return null;    
    }
    }
    
}
